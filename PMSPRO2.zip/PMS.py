import os
import sys
from datetime import datetime
from collections import defaultdict
import bcrypt
import calendar
import tkinter as tk
from tkinter import messagebox, simpledialog, scrolledtext
import re


# Required files to exist before running
FILES = ["inventory.txt", "sales.txt", "customers.txt", "error.txt", "logs.txt"]

# Global variables to keep current logged-in user info
current_user = None
current_role = None

# -------------------- Utility Functions --------------------

def log_action(username, role, action):
    """Log user actions with timestamp."""
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with open("logs.txt", "a") as f:
        f.write(f"{timestamp} | User: {username} | Role: {role} | Action: {action}\n")

def log_error(message):
    """Log error messages to error.txt."""
    with open("error.txt", "a") as f:
        f.write(message + "\n")

def check_files():
    """Ensure required files exist; exit program if missing."""
    missing_files = [f for f in FILES if not os.path.isfile(f)]
    if missing_files:
        for f in missing_files:
            log_error(f"Missing required file: {f}")
        messagebox.showerror("Missing Files",
                             f"Missing files: {', '.join(missing_files)}. Please create them and restart.")
        sys.exit(1)

# -------------------- Authentication --------------------

def authenticate_user(username, password):
    try:
        # Check if the 'users.txt' file exists and use it
        try:
            with open("users.txt", "r") as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) != 3:
                        continue  # Skip lines that don't match the expected format
                    stored_user, hashed_pw, role = parts
                    if stored_user == username and bcrypt.checkpw(password.encode(), hashed_pw.encode()):
                        return role
        except FileNotFoundError:
            log_error("users.txt file not found, falling back to hardcoded users.")

        # Fallback to hardcoded users if the file is not found
        users = {
            "admin": "admin123",
            "p": "3"
        }
        if username in users and password == users[username]:
            return "admin" if username == "admin" else "pharmacist"

        return None

    except Exception as e:
        log_error(f"Login error: {e}")
        return None


def create_user(username, password, role):
    """Creates a new user and saves it to the users.txt file."""
    try:
        # Check if the user already exists
        with open("users.txt", "r") as f:
            for line in f:
                if line.startswith(username):
                    print(f"User {username} already exists!")
                    return

        # Hash the password before storing it
        hashed_pw = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

        with open("users.txt", "a") as f:
            f.write(f"{username} {hashed_pw} {role}\n")

        print(f"User {username} created successfully!")

    except Exception as e:
        log_error(f"Error creating user: {e}")


# Example of how to use the functions:

# Create users (will not add if user already exists)
create_user("admin1", "admin123", "admin")
create_user("pharma1", "pharma123", "pharmacist")
create_user("pharma2", "pharma1234", "pharmacist")

# Example authentication:
role = authenticate_user("admin1", "admin123")
if role:
    print(f"User authenticated as {role}")
else:
    print("Authentication failed")


        # -------------------- GUI Functions --------------------

def clear_window(win):
    """Clear all widgets from a window."""
    for widget in win.winfo_children():
        widget.destroy()

# --------------- Login & Main Menu Windows ----------------

def login_gui(root):
    """Show login window with modern design."""
    global current_user, current_role
    clear_window(root)
    root.geometry("450x300")
    root.configure(bg="#f0f4f7")

    # Title label
    title = tk.Label(root, text="Pharmacy Login", font=("Helvetica", 18, "bold"), bg="#f0f4f7", fg="#333")
    title.pack(pady=20)

    # Username label and entry
    tk.Label(root, text="Username:", font=("Arial", 12), bg="#f0f4f7").pack(pady=(10, 2))
    username_entry = tk.Entry(root, font=("Arial", 12))
    username_entry.pack(ipady=5, ipadx=5)

    # Password label and entry
    tk.Label(root, text="Password:", font=("Arial", 12), bg="#f0f4f7").pack(pady=(10, 2))
    password_entry = tk.Entry(root, font=("Arial", 12), show="*")
    password_entry.pack(ipady=5, ipadx=5)

    def on_login():
        username = username_entry.get().strip()
        password = password_entry.get().strip()

        role = authenticate_user(username, password)
        if role:
            global current_user, current_role
            current_user = username
            current_role = role
            log_action(current_user, current_role, "User logged in")

            messagebox.showinfo("Login Success", f"Welcome {current_user} ({current_role})!")
            if role == "admin":
                show_admin(root)
            else:
                show_pharmacist(root)
        else:
            messagebox.showerror("Login Failed", "Invalid username or password.")

    login_btn = tk.Button(root, text="Login", font=("Arial", 12, "bold"), bg="#4a90e2", fg="white",
                          activebackground="#357ABD", activeforeground="white",
                          command=on_login)
    login_btn.pack(pady=25, ipadx=10, ipady=5)

def show_admin(root):
    """Show Admin dashboard window."""
    global current_user, current_role
    clear_window(root)
    root.geometry("600x450")
    root.configure(bg="#f0f4f7")

    label = tk.Label(root, text=f"Admin Dashboard - {current_user}", font=("Helvetica", 16, "bold"), bg="#f0f4f7", fg="#333")
    label.pack(pady=20)

    # Buttons with commands mapped to functions
    btns = [
        ("Modify Inventory", open_inventory_management),
        ("View Logs", view_logs),
        ("Generate Reports", reporting_gui),
       # ("Search", lambda: search(root)),  # Pass root when calling search
        ("Logout", lambda: logout(root))
    ]

    for (text, cmd) in btns:
        btn = tk.Button(root, text=text, font=("Arial", 13), bg="#4a90e2", fg="white",
                        activebackground="#357ABD", activeforeground="white", command=cmd)
        btn.pack(fill="x", padx=100, pady=10, ipady=10)

def show_pharmacist(root):
    """Show Pharmacist dashboard window."""
    global current_user, current_role
    clear_window(root)
    root.geometry("600x400")
    root.configure(bg="#f0f4f7")

    label = tk.Label(root, text=f"Pharmacist Dashboard - {current_user}", font=("Helvetica", 16, "bold"), bg="#f0f4f7", fg="#333")
    label.pack(pady=20)

    btns = [
        ("Process Sale", process_sale_gui),
        ("View Inventory", display_inventory_gui),
        ("Logout", lambda: logout(root))
    ]

    for (text, cmd) in btns:
        btn = tk.Button(root, text=text, font=("Arial", 13), bg="#4a90e2", fg="white",
                        activebackground="#357ABD", activeforeground="white", command=cmd)
        btn.pack(fill="x", padx=100, pady=10, ipady=10)

def logout(root):
    """Log out current user and return to login screen."""
    global current_user, current_role
    log_action(current_user, current_role, "User logged out")
    current_user = None
    current_role = None
    login_gui(root)

# ------------------ Inventory & Sales & Other GUIs ------------------

def validate_numeric(title, data):
    """Prompt for positive integer input."""
    while True:
        value = simpledialog.askstring(title, data)
        if value is None:  # If user cancels or closes the window
            return None

        if value.isdigit() and int(value) >= 0:
            return int(value)  # Return the valid input as an integer

        messagebox.showerror("Invalid Input", f"{data} must be a positive integer. Please try again!")
        # The loop will continue until a valid input is provided

def valid_date(title, date):
    """Prompt for valid date in YYYY-MM-DD format and future date."""
    while True:
        date_str = simpledialog.askstring(title, date)
        if date_str is None:
            return None

        try:
            dt = datetime.strptime(date_str, "%Y-%m-%d")
            if dt.strftime("%Y-%m-%d") != date_str:
                raise ValueError

            if dt < datetime.now():
                messagebox.showerror("Invalid Date", "Expiry date cannot be in the past.")
                continue

            return date_str

        except:
            messagebox.showerror("Invalid Format", "Date must be in YYYY-MM-DD format")

# -------------------------------  Search Functionality -----------------------------------

# Function to check if the medicine category exists
def medicine_exists_by_category(category):
    """Check if medicine category exists."""
    try:
        with open("inventory.txt", "r") as f:
            category = category.strip().lower()
            for line in f:
                parts = line.strip().split()
                if len(parts) < 6:
                    continue
                if parts[5].strip().lower() == category:
                    return True
        return False
    except Exception as error_Ex:
        log_error(f"Medicine category check error: {error_Ex}")
        return False


# Function to check if the medicine name exists
def medicine_exists_by_name(name):
    """Check if medicine name exists."""
    try:
        with open("inventory.txt", "r") as f:
            name = name.strip().lower()
            for line in f:
                parts = line.strip().split()
                if len(parts) < 6:
                    continue
                if parts[0].strip().lower() == name:
                    return True
        return False
    except Exception as error_Ex:
        log_error(f"Medicine name check error: {error_Ex}")
        return False


# Function to search for medicines by name or category
def search_medicine(query, search_type="name"):
    """Search for medicine by name or category."""
    results = []
    try:
        with open("inventory.txt", "r") as f:
            query = query.strip().lower()
            for line in f:
                parts = line.strip().split()
                if len(parts) < 6:
                    continue
                if search_type == "name" and parts[0].strip().lower() == query:
                    results.append(line.strip())  # Add the full line of the matching medicine
                elif search_type == "category" and parts[5].strip().lower() == query:
                    results.append(line.strip())  # Add the full line of the matching category
        return results  # Return the list of search results
    except Exception as error_Ex:
        log_error(f"Medicine search error: {error_Ex}")
        return []


# Function to view customer purchase history
def view_customer_purchase_history(customer_name):
    """View the purchase history for a specific customer."""
    history = []  # List to store the purchase history for the customer
    try:
        with open("customers.txt", "r") as f:  # Open the customers file for reading
            for line in f:  # Loop through each line in the file
                line = line.strip()  # Remove leading/trailing spaces from each line
                # Split the line using '|' to separate the customer name and their purchases
                parts = line.split("|")

                if len(parts) > 1:
                    customer_in_line = parts[0].strip().lower()  # Remove extra spaces and convert to lowercase
                    if customer_name.strip().lower() == customer_in_line:  # Compare in lowercase
                        # Return the entire line for the customer
                        history.append(line.strip())  # Add the full line (customer and purchases) to history

        return history  # Return the formatted purchase history
    except Exception as error_Ex:
        log_error(f"Customer purchase history error: {error_Ex}")
        return []  # Return an empty list if there's an error


# Function to display message
def display_message(title, message):
    """Display an error or info message."""
    message_window = tk.Toplevel()
    message_window.title(title)
    message_window.geometry("300x150")
    message_label = tk.Label(message_window, text=message, font=("Arial", 12), fg="black")
    message_label.pack(pady=30)
    ok_button = tk.Button(message_window, text="OK", command=message_window.destroy)
    ok_button.pack(pady=10)


# Function to handle the search process
def search(root):
    """Create a search window to search medicines or customer purchase history."""

    def perform_search():
        """Handle the search query and display results"""
        query = search_entry.get().strip()
        search_type = search_type_var.get()

        if not query:
            display_message("Error", "Please enter a valid search query.")
            return

        if search_type == "name" or search_type == "category":
            results = search_medicine(query, search_type)
            if results:
                results_str = "\n".join(results)
                display_message("Search Results", f"Found the following medicines:\n{results_str}")
            else:
                display_message("Search Results", "No medicines found.")
        elif search_type == "customer":
            history = view_customer_purchase_history(query)
            if history:
                history_str = "\n".join(history)
                display_message("Purchase History", f"Purchase history for {query}:\n{history_str}")
            else:
                display_message("Purchase History", "No purchase history found.")

    # Create search window
    search_win = tk.Toplevel(root)
    search_win.title("Search")
    search_win.geometry("400x300")

    search_label = tk.Label(search_win, text="Enter search query:", font=("Arial", 12))
    search_label.pack(pady=10)

    search_entry = tk.Entry(search_win, font=("Arial", 12))
    search_entry.pack(pady=5)

    search_type_var = tk.StringVar(value="name")
    name_radio = tk.Radiobutton(search_win, text="By Name", variable=search_type_var, value="name")
    name_radio.pack(pady=5)
    category_radio = tk.Radiobutton(search_win, text="By Category", variable=search_type_var, value="category")
    category_radio.pack(pady=5)
    customer_radio = tk.Radiobutton(search_win, text="By Customer", variable=search_type_var, value="customer")
    customer_radio.pack(pady=5)

    search_button = tk.Button(search_win, text="Search", font=("Arial", 14), command=perform_search)
    search_button.pack(pady=20)


# -------------------------------  Inventory Management -----------------------------------


def display_inventory_gui():
    try:
        f = open("inventory.txt", "r")
        content = ""
        for line in f:
            parts = line.strip().split()
            if len(parts) < 6:
                log_error(f"Malformed inventory line: {line.strip()}")
                continue
            name, qty, price, cost, expiry, category = parts
            content += (f"Name: {name}\nQuantity: {qty}\nSelling Price: {price}\n"
                        f"Cost Price: {cost}\nExpiry Date: {expiry}\nCategory: {category}\n"
                        "---------------------\n")
        f.close()
    except Exception as error_Ex:
        log_error(f"Error reading inventory: {error_Ex}")
        messagebox.showerror("Error", "Failed to load inventory.")
        return

    win = tk.Toplevel()
    win.title("Inventory")
    txt = scrolledtext.ScrolledText(win, width=70, height=35)
    txt.pack()
    txt.insert(tk.END, content)  # show the inventory file
    txt.configure(state='disabled')


def add_medicine_gui():
    try:
        # Create a new window for adding medicine
        win = tk.Toplevel()  # Toplevel creates a new window
        win.title("Add Medicine")  # Set the title of the window
        win.geometry("500x400")  # Set the size of the window
        win.configure(bg="#f0f4f7")  # Set the background color of the window

        # Add a title label at the top of the window
        title = tk.Label(win, text="Add Medicine", font=("Helvetica", 18, "bold"), bg="#f0f4f7", fg="#333")
        title.grid(row=0, column=0, columnspan=2, pady=20)  # Place the title label in the window using grid

        # Labels and input fields for each required field (medicine name, quantity, price, expiry date, category, cost price)
        labels = [
            "Medicine Name:", "Quantity:", "Price:", "Expiry Date (YYYY-MM-DD):", "Category:", "Cost Price:"
        ]

        # Define variables to store user input
        entries = {}

        # Create labels and input fields dynamically
        for idx, label_text in enumerate(labels):
            label = tk.Label(win, text=label_text, font=("Arial", 12), bg="#f0f4f7")  # Create a label
            label.grid(row=idx + 1, column=0, pady=5, sticky="w")  # Place the label in the grid

            entry = tk.Entry(win, font=("Arial", 12))  # Create an entry field for user input
            entry.grid(row=idx + 1, column=1, pady=5)  # Place the entry field in the grid
            entries[label_text] = entry  # Store the entry field in the dictionary with the label as the key

        # Function to handle saving the medicine data
        def save_medicine():
            name = entries["Medicine Name:"].get().strip()  # Get the input for medicine name
            if medicine_exists_by_name(name):  # Check if the medicine already exists
                messagebox.showwarning("Duplicate", f"Medicine '{name}' already exists.")  # Show warning
                return

            # Validate other inputs (quantity, price, expiry date, category, cost price)
            quantity = entries["Quantity:"].get().strip()
            if not quantity.isdigit() or int(quantity) <= 0:
                messagebox.showerror("Invalid Input", "Quantity must be a positive number.")
                return

            price = entries["Price:"].get().strip()
            if not price.isdigit() or int(price) <= 0:
                messagebox.showerror("Invalid Input", "Price must be a positive number.")
                return

            expiry_date = entries["Expiry Date (YYYY-MM-DD):"].get().strip()
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", expiry_date):
                messagebox.showerror("Invalid Format", "Expiry date must be in YYYY-MM-DD format (e.g., 2026-09-09).")
                return
            try:
                expiry_date_obj = datetime.strptime(expiry_date, "%Y-%m-%d")  # Validate date format
                if expiry_date_obj < datetime.now():  # Check if the expiry date is in the past
                    messagebox.showerror("Expired Date", "Expiry date cannot be in the past.")
                    return
            except ValueError:
                messagebox.showerror("Invalid Date", "Expiry date must be in YYYY-MM-DD format.")
                return

            category = entries["Category:"].get().strip()
            if medicine_exists_by_category(category):
                messagebox.showwarning("Duplicate", f"Category '{category}' already used for another medicine")
                return

            cost_price = entries["Cost Price:"].get().strip()
            if not cost_price.isdigit() or int(cost_price) <= 0:
                messagebox.showerror("Invalid Input", "Cost Price must be a positive number.")
                return

            # Try to open the inventory file and append the new medicine
            try:
                with open("inventory.txt", "r") as f:
                    content = f.read()
                    needs_newline = len(content) > 0 and not content.endswith('\n')  # Check if newline is needed
            except FileNotFoundError:
                needs_newline = False

            # Write the new medicine data to the inventory file
            with open("inventory.txt", "a") as f:
                if needs_newline:
                    f.write('\n')  # Add a newline if necessary
                f.write(f"{name} {quantity} {price} {cost_price} {expiry_date} {category}\n")

            messagebox.showinfo("Success", f"Medicine '{name}' added!")  # Show success message
            if current_user and current_role:
                log_action(current_user, current_role, f"Added new medicine: {name}")
            win.destroy()  # Close the add medicine window

        # Add a save button that triggers the save_medicine function
        save_btn = tk.Button(win, text="Save Medicine", font=("Arial", 14, "bold"), bg="#4a90e2", fg="white",
                             activebackground="#357ABD", activeforeground="white", command=save_medicine)
        save_btn.grid(row=len(labels) + 1, column=0, columnspan=2, pady=20)  # Place the button at the bottom

    except Exception as error_Ex:
        log_error(f"Add medicine error: {error_Ex}")  # Log any errors
        messagebox.showerror("Error", str(error_Ex))  # Show error message

def update_medicine_gui():
    try:
        win = tk.Toplevel()
        win.title("Update Medicine")
        win.geometry("500x400")
        win.configure(bg="#f0f4f7")

        title = tk.Label(win, text="Update Medicine", font=("Helvetica", 18, "bold"), bg="#f0f4f7", fg="#333")
        title.grid(row=0, column=0, columnspan=2, pady=20)

        # Step 1: Enter medicine name
        tk.Label(win, text="Medicine Name:", font=("Arial", 12), bg="#f0f4f7").grid(row=1, column=0, pady=5, sticky="w")
        medicine_name_entry = tk.Entry(win, font=("Arial", 12))
        medicine_name_entry.grid(row=1, column=1, pady=5)

        # Placeholder for fields and update button
        field_widgets = []

        def ask_field_choice():
            name = medicine_name_entry.get().strip()
            if not name:
                messagebox.showwarning("Input Required", "Please enter a medicine name first.")
                return

            # Check if the medicine exists
            found = False
            try:
                with open("inventory.txt", "r") as f:
                    for line in f:
                        if line.strip().split()[0].lower() == name.lower():
                            found = True
                            break
            except FileNotFoundError:
                messagebox.showerror("Error", "Inventory file not found.")
                return

            if not found:
                messagebox.showinfo("Not Found", f"Medicine '{name}' not found.")
                return

            # Ask what to update
            field_choice = simpledialog.askstring("Select Field to Update",
                                                  "Choose the field to update:\n1- Quantity\n2- Price\n3- Cost Price\n4- All")

            if not field_choice:
                return

            # Clear previous widgets below row 2
            for widget in field_widgets:
                widget.destroy()
            field_widgets.clear()

            entries = {}

            row = 2

            if field_choice == '1':
                lbl = tk.Label(win, text="Quantity:", font=("Arial", 12), bg="#f0f4f7")
                lbl.grid(row=row, column=0, pady=5, sticky="w")
                entry = tk.Entry(win, font=("Arial", 12))
                entry.grid(row=row, column=1, pady=5)
                entries["Quantity"] = entry
                field_widgets.extend([lbl, entry])

            elif field_choice == '2':
                lbl = tk.Label(win, text="Price:", font=("Arial", 12), bg="#f0f4f7")
                lbl.grid(row=row, column=0, pady=5, sticky="w")
                entry = tk.Entry(win, font=("Arial", 12))
                entry.grid(row=row, column=1, pady=5)
                entries["Price"] = entry
                field_widgets.extend([lbl, entry])

            elif field_choice == '3':
                lbl = tk.Label(win, text="Cost Price:", font=("Arial", 12), bg="#f0f4f7")
                lbl.grid(row=row, column=0, pady=5, sticky="w")
                entry = tk.Entry(win, font=("Arial", 12))
                entry.grid(row=row, column=1, pady=5)
                entries["Cost Price"] = entry
                field_widgets.extend([lbl, entry])

            elif field_choice == '4':
                labels = ["Quantity", "Price", "Cost Price"]
                for label in labels:
                    lbl = tk.Label(win, text=f"{label}:", font=("Arial", 12), bg="#f0f4f7")
                    lbl.grid(row=row, column=0, pady=5, sticky="w")
                    entry = tk.Entry(win, font=("Arial", 12))
                    entry.grid(row=row, column=1, pady=5)
                    entries[label] = entry
                    field_widgets.extend([lbl, entry])
                    row += 1
            else:
                messagebox.showerror("Invalid Choice", "Please enter a valid option (1, 2, 3, or 4).")
                return

            # Create update button
            update_btn = tk.Button(win, text="Update Medicine", font=("Arial", 14, "bold"),
                                   bg="#4a90e2", fg="white", command=lambda: update_medicine(name, entries))
            update_btn.grid(row=row + 1, column=0, columnspan=2, pady=20)
            field_widgets.append(update_btn)

        # Show "Next" button after entering name
        next_btn = tk.Button(win, text="Next", font=("Arial", 12), bg="#2196F3", fg="white", command=ask_field_choice)
        next_btn.grid(row=1, column=2, padx=10)

        def update_medicine(name, entries):
            updated = False
            lines = []

            try:
                with open("inventory.txt", "r") as f:
                    for line in f:
                        parts = line.strip().split()
                        if len(parts) < 6:
                            lines.append(line)
                            continue

                        if parts[0].lower() == name.lower():
                            # Validate and update fields
                            if "Quantity" in entries:
                                quantity = entries["Quantity"].get().strip()
                                if not quantity.isdigit() or int(quantity) <= 0:  # Check if quantity is positive number
                                    messagebox.showerror("Invalid Input", "Please enter a valid positive quantity.")
                                    return
                                parts[1] = quantity

                            if "Price" in entries:
                                price = entries["Price"].get().strip()
                                try:
                                    price_value = float(price)
                                    if price_value <= 0:  # Ensure price is positive
                                        messagebox.showerror("Invalid Input", "Please enter a valid positive price.")
                                        return
                                    parts[2] = price
                                except ValueError:
                                    messagebox.showerror("Invalid Input", "Please enter a valid price.")
                                    return

                            if "Cost Price" in entries:
                                cost_price = entries["Cost Price"].get().strip()
                                try:
                                    cost_value = float(cost_price)
                                    if cost_value <= 0:  # Ensure cost price is positive
                                        messagebox.showerror("Invalid Input", "Please enter a valid positive cost price.")
                                        return
                                    parts[3] = cost_price
                                except ValueError:
                                    messagebox.showerror("Invalid Input", "Please enter a valid cost price.")
                                    return

                            updated = True
                            line = " ".join(parts) + "\n"
                        lines.append(line)

                if updated:
                    with open("inventory.txt", "w") as f:
                        f.writelines(lines)
                    log_action(current_user, current_role, f"Updated medicine '{name}'")
                    messagebox.showinfo("Success", f"Medicine '{name}' updated.")
                    win.destroy()
                else:
                    messagebox.showinfo("Not Found", f"Medicine '{name}' not found.")

            except Exception as e:
                log_error(f"Update medicine error: {e}")
                messagebox.showerror("Error", str(e))

    except Exception as error_Ex:
        log_error(f"Update medicine error: {error_Ex}")
        messagebox.showerror("Error", str(error_Ex))

def remove_expired_gui():
    try:
        today = datetime.now()
        updated_lines = []
        f = open("inventory.txt", "r")
        for line in f:
            parts = line.strip().split()
            if len(parts) < 6:
                log_error(f"incorrect inventory line: {line.strip()}")
                continue
            name, quantity, price, cost_price, expiry, category = parts
            try:
                expiry_date = datetime.strptime(expiry, "%Y-%m-%d")
            except Exception:
                log_error(f"Invalid expiry date for {name}: {expiry}")
                continue
            if expiry_date >= today:
                updated_lines.append(line)
            else:
                lf = open("logs.txt", "a")
                lf.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} Removed expired: {name} ({expiry})\n")

        f = open("inventory.txt", "w")
        f.writelines(updated_lines)
        messagebox.showinfo("Success", "Expired medicines removed.")
        if current_user and current_role:
            log_action(current_user, current_role, "Removed expired medicines")

    except Exception as error_Ex:
        log_error(f"Remove expired error: {error_Ex}")
        messagebox.showerror("Error", str(error_Ex))

def open_inventory_management():
    inv_win = tk.Toplevel()
    inv_win.title("Inventory Management")

    # List of buttons to be created
    buttons = [
        ("Display Inventory", display_inventory_gui),
        ("Add Medicine", add_medicine_gui),
        ("Update Medicine", update_medicine_gui),
        ("Remove Expired Medicines", remove_expired_gui),
        ("Logout", inv_win.destroy)

    ]

    # Creating and packing the buttons
    for (text, cmd) in buttons:
        btn = tk.Button(inv_win, text=text, width=40, height=2, command=cmd, bg="#4a90e2", fg="white",
                        activebackground="#357ABD", activeforeground="white", font=('Arial', 12, 'bold'))
        btn.pack(pady=8)

def view_logs():
    """Open a window to view logs file."""
    win = tk.Toplevel()
    win.title("Logs Viewer")
    win.geometry("900x600")
    txt = scrolledtext.ScrolledText(win, width=110, height=35)
    txt.pack()

    try:
        f = open("logs.txt", "r")
        txt.insert(tk.END, f.read())
        f.close()
    except:
        txt.insert(tk.END, "No logs found.")

    txt.config(state='disabled')
# ------------------------------- Reporting + Enhanced Reporting -----------------------------------

def reporting_gui():
    """Show reporting menu and handle reports generation."""
    global current_user, current_role

    def low_stock_report():
        try:
            # Create a new window for low stock report
            report_win = tk.Toplevel()
            report_win.title("Low Stock Report")
            report_win.geometry("500x400")
            report_win.configure(bg="#4a90e2")  # Blue background

            # Title label
            title_label = tk.Label(report_win, text="Low Stock Medicines", font=("Helvetica", 16, "bold"), bg="#4a90e2",
                                   fg="white")
            title_label.pack(pady=10)

            # Add a label and entry widget to get the stock threshold from the user
            threshold_label = tk.Label(report_win, text="Enter stock threshold:", font=("Arial", 12), bg="#4a90e2",
                                       fg="white")
            threshold_label.pack(pady=10)

            threshold_entry = tk.Entry(report_win, font=("Arial", 12), width=15)
            threshold_entry.pack(pady=5)

            # Function to generate the low stock report
            def generate_report():
                threshold_str = threshold_entry.get().strip()
                if not threshold_str.isdigit():
                    messagebox.showerror("Invalid Input", "Please enter a valid numeric threshold.")
                    return
                threshold = int(threshold_str)

                low_stock = []
                try:
                    with open("inventory.txt") as f:
                        for line in f:
                            parts = line.strip().split()
                            if len(parts) < 6:
                                continue
                            name = parts[0]
                            try:
                                qty = int(parts[1])
                            except ValueError:
                                continue
                            if qty <= threshold:
                                low_stock.append(f"{name} (Quantity: {qty})")
                except Exception as e:
                    log_error(f"Error reading inventory for low stock: {e}")
                    messagebox.showerror("Error", "Failed to read inventory.")
                    return

                # Create a Text widget to display the low stock list
                text_widget = tk.Text(report_win, font=("Arial", 12), wrap="word", height=10, width=40, bg="#e1f5fe",
                                      fg="#333")
                text_widget.pack(padx=10, pady=10)

                if low_stock:
                    text_widget.insert(tk.END, "\n".join(low_stock))
                else:
                    text_widget.insert(tk.END, "No medicines below threshold.")

                # Make the Text widget read-only
                text_widget.config(state=tk.DISABLED)
                #  Log the report generation
                log_action(current_user, current_role, "Generated Low Stock Report")

            # Add a button to generate the low stock report
            generate_btn = tk.Button(report_win, text="Generate Report", font=("Arial", 14, "bold"), bg="#357ABD",
                                     fg="white", command=generate_report)
            generate_btn.pack(pady=20)

        except Exception as e:
            log_error(f"Error in low stock report generation: {e}")
            messagebox.showerror("Error", "Failed to generate low stock report.")


    def expired_report():
        try:
            today_str = datetime.now().strftime("%Y-%m-%d")
            expired = []

            # Read the inventory file
            with open("inventory.txt") as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) < 6:
                        continue
                    name, expiry = parts[0], parts[4]
                    if expiry < today_str:
                        expired.append(f"{name} (Expiry: {expiry})")

            # Create a new window for displaying the expired medicines report
            report_win = tk.Toplevel()
            report_win.title("Expired Medicines Report")
            report_win.geometry("400x300")
            report_win.configure(bg="#4a90e2")  # Blue background

            # Title label
            title_label = tk.Label(report_win, text="Expired Medicines Report", font=("Helvetica", 16, "bold"),
                                   bg="#4a90e2", fg="white")
            title_label.pack(pady=10)

            # Create a Text widget to display the expired medicines list
            text_widget = tk.Text(report_win, font=("Arial", 12), wrap="word", height=10, width=40, bg="#e1f5fe",
                                  fg="#333")
            text_widget.pack(padx=10, pady=10)

            # If there are expired medicines, show them
            if expired:
                text_widget.insert(tk.END, "\n".join(expired))
            else:
                text_widget.insert(tk.END, "No expired medicines found.")

            # Make the Text widget read-only
            text_widget.config(state=tk.DISABLED)

            # Log the action
            if current_user and current_role:
                log_action(current_user, current_role, "Generated Expired Medicines Report")

        except Exception as e:
            log_error(f"Error in expired medicines report: {e}")
            messagebox.showerror("Error", "Failed to generate expired medicines report.")

    import tkinter as tk
    from tkinter import messagebox
    from datetime import datetime
    import re

    def sales_report():
        try:
            # Create a new window for the sales report
            report_win = tk.Toplevel()
            report_win.title("Sales Report")
            report_win.geometry("500x400")
            report_win.configure(bg="#4a90e2")  # Blue background

            # Add a title label
            title_label = tk.Label(report_win, text="Sales Report", font=("Helvetica", 16, "bold"), bg="#4a90e2",
                                   fg="white")
            title_label.pack(pady=10)

            # Add label and entry for start date
            start_label = tk.Label(report_win, text="Enter start date (YYYY-MM-DD):", font=("Arial", 12), bg="#4a90e2",
                                   fg="white")
            start_label.pack(pady=5)

            start_entry = tk.Entry(report_win, font=("Arial", 12))
            start_entry.pack(pady=5)

            # Add label and entry for end date
            end_label = tk.Label(report_win, text="Enter end date (YYYY-MM-DD):", font=("Arial", 12), bg="#4a90e2",
                                 fg="white")
            end_label.pack(pady=5)

            end_entry = tk.Entry(report_win, font=("Arial", 12))
            end_entry.pack(pady=5)

            # Function to ensure the date is in the correct format (with leading zeros)
            def format_date(date_str):
                pattern = r'^\d{4}-\d{2}-\d{2}$'
                if re.match(pattern, date_str):
                    try:
                        # Try to parse the date to ensure it is a valid date
                        datetime.strptime(date_str, "%Y-%m-%d")
                        return True
                    except ValueError:
                        return False
                return False

            # Function to generate the sales report
            def generate_report():
                # Getting the values from the entries
                start = start_entry.get().strip()  # Get the start date from entry
                end = end_entry.get().strip()  # Get the end date from entry
                # Validate the date format
                if not format_date(start) or not format_date(end):
                    display_message("Error", "Invalid date format. Please use YYYY-MM-DD.")
                    return
                # Validate the date range
                try:
                    sd = datetime.strptime(start, "%Y-%m-%d")
                    ed = datetime.strptime(end, "%Y-%m-%d")
                    if sd > ed:
                        display_message("Error", "Start date must not be after end date.")
                        return
                except ValueError:
                    display_message("Error", "Invalid date format. Please use YYYY-MM-DD.")
                    return

                report = []
                inside = False

                try:
                    # Check if the sales.txt file exists and can be read
                    with open("sales.txt") as f:
                        for line in f:
                            if line.startswith("===== Sales for "):
                                parts = line.strip().split()
                                if len(parts) < 4:
                                    continue
                                sale_date = parts[3]
                                try:
                                    dt = datetime.strptime(sale_date, "%Y-%m-%d")
                                except ValueError:
                                    continue
                                inside = (sd <= dt <= ed)
                                if inside:
                                    report.append(line.strip())
                            elif inside:
                                report.append(line.strip())
                except FileNotFoundError:
                    display_message("Error", "sales.txt file not found.")
                    return
                except Exception as e:
                    display_message("Error", f"Error reading sales data: {str(e)}")
                    return

                # Create a Text widget to display the sales report
                text_widget = tk.Text(report_win, font=("Arial", 12), wrap="word", height=10, width=40, bg="#e1f5fe",
                                      fg="#333")
                text_widget.pack(padx=10, pady=10)

                # Show the report or a message if no data is found
                msg = "\n".join(report) if report else "No sales data in given period."
                text_widget.insert(tk.END, msg)

                # Make the Text widget read-only
                text_widget.config(state=tk.DISABLED)

            # Add a button to generate the report
            generate_btn = tk.Button(report_win, text="Generate Report", font=("Arial", 14, "bold"), bg="#357ABD",
                                     fg="white", command=generate_report)
            generate_btn.pack(pady=20)

        except Exception as e:
            messagebox.showerror("Error", "Failed to generate sales report.")


    # Helper function to display messages inside the GUI
    def display_message(title, message):
        message_window = tk.Toplevel()
        message_window.title(title)
        message_window.geometry("300x150")
        message_label = tk.Label(message_window, text=message, font=("Arial", 12), fg="black")
        message_label.pack(pady=30)
        ok_button = tk.Button(message_window, text="OK", command=message_window.destroy)
        ok_button.pack(pady=10)

    def top_k_report():
        try:
            # Create a new window for Top K report
            report_win = tk.Toplevel()
            report_win.title("Top K Medicines")
            report_win.geometry("500x400")
            report_win.configure(bg="#4a90e2")  # Blue background

            # Add a title label
            title_label = tk.Label(report_win, text="Top K Medicines Report", font=("Helvetica", 16, "bold"),
                                   bg="#4a90e2", fg="white")
            title_label.pack(pady=10)

            # Add label and entry for K
            k_label = tk.Label(report_win, text="Enter K (Top K):", font=("Arial", 12), bg="#4a90e2", fg="white")
            k_label.pack(pady=5)

            k_entry = tk.Entry(report_win, font=("Arial", 12), width=10)
            k_entry.pack(pady=5)

            # Function to generate the Top K report
            def generate_report():
                # Get the value of K from the entry
                k_input = k_entry.get().strip()
                if not k_input.isdigit() or int(k_input) <= 0:
                    messagebox.showerror("Invalid Input", "Please enter a valid positive integer for K.")
                    return
                k = int(k_input)  # Correctly define k

                totals = {}
                try:
                    with open("sales.txt") as f:
                        for line in f:
                            if line.startswith("===== Sales for "):
                                continue
                            parts = line.strip().split()
                            if len(parts) < 6:
                                continue
                            name = parts[1]
                            qty = int(parts[3]) if parts[3].isdigit() else 0
                            totals[name] = totals.get(name, 0) + qty
                except Exception as e:
                    log_error(f"Error reading sales for top K: {e}")
                    messagebox.showerror("Error", "Failed to read sales data.")
                    return

                sorted_totals = sorted(totals.items(), key=lambda x: x[1], reverse=True)
                report = "\n".join([f"{name}: {qty}" for name, qty in sorted_totals[:k]])

                # If no data, show this message
                if not report:
                    report = "No sales data available."

                # Create a Text widget to display the Top K report
                text_widget = tk.Text(report_win, font=("Arial", 12), wrap="word", height=10, width=40, bg="#e1f5fe",
                                      fg="#333")
                text_widget.pack(padx=10, pady=10)

                # Insert the report into the Text widget
                text_widget.insert(tk.END, report)

                # Make the Text widget read-only
                text_widget.config(state=tk.DISABLED)

                # Log the action with the correct 'k' value
                if current_user and current_role:
                    log_action(current_user, current_role, f"Generated Top {k} Medicines Report")

            # Add a button to generate the Top K report
            generate_btn = tk.Button(report_win, text="Generate Report", font=("Arial", 14, "bold"), bg="#357ABD",
                                     fg="white", command=generate_report)
            generate_btn.pack(pady=20)

        except Exception as e:
            messagebox.showerror("Error", "Failed to generate Top K medicines report.")

    def sales_trends_report():
        try:
            # Create a new window for Sales Trends Report
            report_win = tk.Toplevel()
            report_win.title("Sales Trends Report")
            report_win.geometry("500x400")
            report_win.configure(bg="#4a90e2")  # Blue background

            # Add a title label
            title_label = tk.Label(report_win, text="Sales Trends Report", font=("Helvetica", 16, "bold"), bg="#4a90e2",
                                   fg="white")
            title_label.pack(pady=10)

            # Add label and entry for period (monthly, quarterly, yearly)
            period_label = tk.Label(report_win, text="Select period (monthly, quarterly, yearly):", font=("Arial", 12),
                                    bg="#4a90e2", fg="white")
            period_label.pack(pady=5)

            period_entry = tk.Entry(report_win, font=("Arial", 12))
            period_entry.pack(pady=5)

            # Add label and entry for month (if monthly selected)
            month_label = tk.Label(report_win, text="Enter the month number (1-12):", font=("Arial", 12), bg="#4a90e2",
                                   fg="white")
            month_label.pack(pady=5)
            month_label.pack_forget()  # Initially hide the month field

            month_entry = tk.Entry(report_win, font=("Arial", 12))
            month_entry.pack(pady=5)
            month_entry.pack_forget()  # Initially hide the month field

            # Add label and entry for quarter (if quarterly selected)
            quarter_label = tk.Label(report_win, text="Enter the quarter number (1-4):", font=("Arial", 12),
                                     bg="#4a90e2", fg="white")
            quarter_label.pack(pady=5)
            quarter_label.pack_forget()  # Initially hide the quarter field

            quarter_entry = tk.Entry(report_win, font=("Arial", 12))
            quarter_entry.pack(pady=5)
            quarter_entry.pack_forget()  # Initially hide the quarter field

            # Add label and entry for year
            year_label = tk.Label(report_win, text="Enter the year (e.g., 2024):", font=("Arial", 12), bg="#4a90e2",
                                  fg="white")
            year_label.pack(pady=5)

            year_entry = tk.Entry(report_win, font=("Arial", 12))
            year_entry.pack(pady=5)

            # Function to show or hide fields based on selected period
            def update_fields():
                period = period_entry.get().strip().lower()
                if period == "monthly":
                    month_label.pack(pady=5)
                    month_entry.pack(pady=5)
                    quarter_label.pack_forget()
                    quarter_entry.pack_forget()
                elif period == "quarterly":
                    month_label.pack_forget()
                    month_entry.pack_forget()
                    quarter_label.pack(pady=5)
                    quarter_entry.pack(pady=5)
                else:  # yearly
                    month_label.pack_forget()
                    month_entry.pack_forget()
                    quarter_label.pack_forget()
                    quarter_entry.pack_forget()

            # Function to generate the Sales Trends report
            def generate_report():
                # Get the values from the entries
                period = period_entry.get().strip().lower()
                if period not in ("monthly", "quarterly", "yearly"):
                    messagebox.showerror("Invalid Input", "Please enter a valid period: monthly, quarterly, or yearly.")
                    return

                try:
                    month = int(month_entry.get().strip()) if period == "monthly" else None
                    quarter = int(quarter_entry.get().strip()) if period == "quarterly" else None
                    year = int(year_entry.get().strip())
                except ValueError:
                    messagebox.showerror("Invalid Input", "Please enter valid numbers for month, quarter, and year.")
                    return

                sales_data = defaultdict(lambda: defaultdict(int))
                current_date = None

                # Read the sales data from the file
                with open("sales.txt") as f:
                    for line in f:
                        line = line.strip()
                        if line.startswith("===== Sales for "):
                            try:
                                date_str = line.split("Sales for ")[1].split(" =====")[0]
                                current_date = datetime.strptime(date_str, "%Y-%m-%d")
                            except Exception:
                                current_date = None
                            continue
                        if not line or current_date is None:
                            continue
                        parts = line.split()
                        if len(parts) < 6:
                            continue

                        if period == "monthly":
                            if current_date.year != year or current_date.month != month:
                                continue
                            current_period = f"{year}-{month:02d}"
                        elif period == "quarterly":
                            dt_quarter = (current_date.month - 1) // 3 + 1
                            if current_date.year != year or dt_quarter != quarter:
                                continue
                            current_period = f"{year}-Q{quarter}"
                        else:
                            if current_date.year != year:
                                continue
                            current_period = str(year)

                        med = parts[1]
                        try:
                            qty_index = parts.index("Quantity:") + 1
                            qty = int(parts[qty_index])
                        except (ValueError, IndexError):
                            qty = 0

                        sales_data[current_period][med] += qty

                # Display results in a text widget
                if not sales_data:
                    messagebox.showinfo("Sales Trends", "No sales data found for the selected period.")
                    return

                report = ""
                for period_name, meds in sorted(sales_data.items()):
                    if period == "monthly":
                        y, m = period_name.split("-")
                        month_name = calendar.month_name[int(m)]
                        report += f"Sales for {month_name} {y}:\n"
                    elif period == "quarterly":
                        report += f"Sales for {period_name}:\n"
                    else:
                        report += f"Sales for {period_name}:\n"

                    for med_name, qty in meds.items():
                        report += f"  {med_name}: {qty} units\n"
                    report += "\n"

                # Create a Text widget to display the report
                text_widget = tk.Text(report_win, font=("Arial", 12), wrap="word", height=10, width=40, bg="#e1f5fe",
                                      fg="#333")
                text_widget.pack(padx=10, pady=10)

                # Insert the report into the Text widget
                text_widget.insert(tk.END, report)

                # Make the Text widget read-only
                text_widget.config(state=tk.DISABLED)
                if current_user and current_role:
                    log_action(current_user, current_role, f"Generated Sales Trends Report for period: {period}")

            # Add a button to generate the report
            generate_btn = tk.Button(report_win, text="Generate Report", font=("Arial", 14, "bold"), bg="#357ABD",
                                     fg="white", command=generate_report)
            generate_btn.pack(pady=20)

            # Update fields based on selected period
            period_entry.bind("<KeyRelease>", lambda event: update_fields())  # Trigger update on input change

        except Exception as e:
            messagebox.showerror("Error", f"Error in sales trends analysis: {e}")

    def profit_calc_report():
        try:
            # Create a new window for Profit Calculation Report
            report_win = tk.Toplevel()
            report_win.title("Profit Calculation Report")
            report_win.geometry("500x400")
            report_win.configure(bg="#4a90e2")  # Blue background

            # Add a title label
            title_label = tk.Label(report_win, text="Profit Calculation Report", font=("Helvetica", 16, "bold"),
                                   bg="#4a90e2", fg="white")
            title_label.pack(pady=10)

            # Add label and entry for start date
            start_label = tk.Label(report_win, text="Start date (YYYY-MM-DD):", font=("Arial", 12), bg="#4a90e2",
                                   fg="white")
            start_label.pack(pady=5)

            start_entry = tk.Entry(report_win, font=("Arial", 12))
            start_entry.pack(pady=5)

            # Add label and entry for end date
            end_label = tk.Label(report_win, text="End date (YYYY-MM-DD):", font=("Arial", 12), bg="#4a90e2",
                                 fg="white")
            end_label.pack(pady=5)

            end_entry = tk.Entry(report_win, font=("Arial", 12))
            end_entry.pack(pady=5)

            # Function to ensure the date is in the correct format (with leading zeros)
            def format_date(date_str):
                pattern = r'^\d{4}-\d{2}-\d{2}$'
                if re.match(pattern, date_str):
                    try:
                        # Try to parse the date to ensure it is a valid date
                        datetime.strptime(date_str, "%Y-%m-%d")
                        return True
                    except ValueError:
                        return False
                return False

            # Function to generate the profit calculation report
            def generate_report():
                start = start_entry.get().strip()
                end = end_entry.get().strip()

                if not format_date(start) or not format_date(end):
                    display_message("Error", "Invalid date format. Please use YYYY-MM-DD.")
                    return

                try:
                    sd = datetime.strptime(start, "%Y-%m-%d")
                    ed = datetime.strptime(end, "%Y-%m-%d")
                    if sd > ed:
                        messagebox.showerror("Error", "Start date must not be after end date.")
                        return
                except ValueError:
                    messagebox.showerror("Error", "Invalid date format. Please use YYYY-MM-DD.")
                    return

                prices = {}
                with open("inventory.txt") as f:
                    for line in f:
                        parts = line.strip().split()
                        if len(parts) < 6:
                            continue
                        name, _, sp, cp, _, _ = parts
                        prices[name] = (int(sp), int(cp))

                total_profit = 0
                report = ""
                with open("sales.txt") as f:
                    inside = False
                    for line in f:
                        if line.startswith("===== Sales for "):
                            parts = line.strip().split()
                            if len(parts) < 4:
                                inside = False
                                continue
                            dstr = parts[3]
                            dt = datetime.strptime(dstr, "%Y-%m-%d")
                            inside = (sd <= dt <= ed)
                        elif inside:
                            parts = line.strip().split()
                            if len(parts) < 6:
                                continue
                            med = parts[1]
                            qty = int(parts[3]) if parts[3].isdigit() else 0
                            sp, cp = prices.get(med, (0, 0))
                            profit = (sp - cp) * qty
                            total_profit += profit
                            report += f"{med}: Profit = ({sp} - {cp}) * {qty} = {profit}\n"

                report += f"\nTotal profit from {start} to {end}: {total_profit}"

                # Create a Text widget to display the report
                text_widget = tk.Text(report_win, font=("Arial", 12), wrap="word", height=10, width=40, bg="#e1f5fe",
                                      fg="#333")
                text_widget.pack(padx=10, pady=10)

                # Insert the report into the Text widget
                text_widget.insert(tk.END, report)

                # Make the Text widget read-only
                text_widget.config(state=tk.DISABLED)

                if current_user and current_role:
                    log_action(current_user, current_role, f"Generated Profit Report ({start} to {end})")

            # Add a button to generate the report
            generate_btn = tk.Button(report_win, text="Generate Report", font=("Arial", 14, "bold"), bg="#357ABD",
                                     fg="white", command=generate_report)
            generate_btn.pack(pady=20)

        except Exception as e:
            messagebox.showerror("Error", "Error in profit calculation.")

    win = tk.Toplevel()
    win.title("Reports")
    win.geometry("800x600")
    win.configure(bg="#f0f4f7")

    buttons = [
        ("Low Stock Report", low_stock_report),
        ("Expired Medicines Report", expired_report),
        ("Sales Report", sales_report),
        ("Top K Medicines", top_k_report),
        ("Sales Trends Analysis", sales_trends_report),
        ("Profit Calculation", profit_calc_report),
        ("Close", win.destroy)
    ]

    for (text, cmd) in buttons:
        btn = tk.Button(win, text=text, width=40, height=2, command=cmd, bg="#4a90e2", fg="white",
                        activebackground="#357ABD", activeforeground="white")
        btn.pack(pady=8)
# -------------------------------Sales Management  -----------------------------------

def process_sale_gui():
    try:
        check_files()

        total_price = 0
        purchases = {}
        sales_data = []
        current_date = datetime.now().strftime("%Y-%m-%d")

        win = tk.Toplevel()
        win.title("Process Sale")
        win.geometry("600x650")

        # Customer Frame
        customer_frame = tk.Frame(win)
        customer_frame.pack(pady=20)

        tk.Label(customer_frame, text="Customer Name:", font=("Arial", 12)).grid(row=0, column=0, padx=10)
        customer_entry = tk.Entry(customer_frame, font=("Arial", 12))
        customer_entry.grid(row=0, column=1, padx=10)

        customer_label = tk.Label(win, text="Customer: ", font=("Arial", 12))
        customer_label.pack(pady=10)

        def process_customer():
            name = customer_entry.get().strip()
            if name:
                customer_label.config(text=f"Customer: {name}")
                customer_entry.config(state='disabled')
            else:
                messagebox.showerror("Error", "Enter a customer name.")

        tk.Button(customer_frame, text="Process Customer", font=("Arial", 12), command=process_customer).grid(row=1, columnspan=2, pady=10)

        # Medicine Frame
        medicine_frame = tk.Frame(win)
        medicine_frame.pack(pady=10)
        # Instruction label above medicine name input
        tk.Label(medicine_frame, text="Enter medicine name or type 'done' to finish", font=("Arial", 10, "italic"),
                 fg="gray").grid(row=0, column=0, columnspan=2, pady=(0, 5))

        # Medicine Name Label + Entry
        tk.Label(medicine_frame, text="Medicine Name:", font=("Arial", 12)).grid(row=1, column=0, padx=10)
        medicine_entry = tk.Entry(medicine_frame, font=("Arial", 12))
        medicine_entry.grid(row=1, column=1)

        # Quantity Label + Entry
        tk.Label(medicine_frame, text="Quantity:", font=("Arial", 12)).grid(row=2, column=0, padx=10)
        quantity_entry = tk.Entry(medicine_frame, font=("Arial", 12))
        quantity_entry.grid(row=2, column=1)

        # Receipt
        receipt_label = tk.Label(win, text="Receipt", font=("Arial", 14, "bold"))
        receipt_label.pack()
        receipt_text = tk.Text(win, width=60, height=12, font=("Arial", 12))
        receipt_text.pack(pady=10)

        def update_receipt():
            receipt_text.delete(1.0, tk.END)
            receipt_text.insert(tk.END, f"Customer: {customer_entry.get().strip()}\nDate: {current_date}\n\n")
            receipt_text.insert(tk.END, "Purchases:\n")
            for med, qty in purchases.items():
                receipt_text.insert(tk.END, f"- {med}: {qty} units\n")
            receipt_text.insert(tk.END, f"\nTotal Price: {total_price} ILS")

        def complete_sale():
            if not purchases:
                messagebox.showinfo("Nothing Bought", "No items were added.")
                return
            for sale in sales_data:
                update_sales_file(current_date, sale["medicine"], sale["quantity"], sale["total"])
            update_customer_history(customer_entry.get().strip(), purchases, current_date)
            update_receipt()
            receipt_text.insert(tk.END, "\n\n Sale completed. No further medicines can be added.")

            # Disable all input fields after sale is complete
            medicine_entry.config(state='disabled')
            quantity_entry.config(state='disabled')
            log_action(current_user, current_role,
                       f"Processed sale for customer '{customer_entry.get().strip()}' - Total: {total_price} ILS")

        def process_medicine():
            nonlocal total_price

            med_name = medicine_entry.get().strip()
            qty = quantity_entry.get().strip()

            if med_name.lower() == "done":
                complete_sale()
                return

            if not med_name or not qty.isdigit():
                messagebox.showerror("Invalid Input", "Enter valid medicine name and quantity.")
                return

            qty = int(qty)

            found = None
            with open("inventory.txt") as f:
                for line in f:
                    if line.lower().startswith(med_name.lower() + " "):
                        found = line.strip().split()
                        break

            if not found:
                messagebox.showerror("Not Found", f"{med_name} not found in inventory.")
                return

            inv_name, inv_qty, inv_price, _, _, _ = found
            inv_qty = int(inv_qty)
            inv_price = int(inv_price)

            if qty > inv_qty:
                messagebox.showerror("Stock Error", f"Only {inv_qty} units available.")
                return

            purchases[med_name] = purchases.get(med_name, 0) + qty
            sales_data.append({"medicine": med_name, "quantity": qty, "price": inv_price, "total": inv_price * qty})
            total_price += inv_price * qty

            update_inventory_quantity(med_name, inv_qty - qty)
            update_receipt()

        tk.Button(win, text="Add Medicine to Sale", font=("Arial", 12), command=process_medicine).pack(pady=10)

    except Exception as e:
        log_error(f"Sale processing error: {e}")
        messagebox.showerror("Error", str(e))


def update_inventory_quantity(med_name, new_quantity):
    """Update medicine quantity in inventory.txt"""
    try:
        lines = []
        with open("inventory.txt") as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) < 6:
                    lines.append(line)
                    continue
                name = parts[0]
                if name.lower() == med_name.lower():
                    parts[1] = str(new_quantity)
                    line = " ".join(parts) + "\n"
                lines.append(line)
        with open("inventory.txt", "w") as f:
            f.writelines(lines)
    except Exception as e:
        log_error(f"Error updating inventory quantity: {e}")
        messagebox.showerror("Error", "Failed to update inventory.")


def update_sales_file(date_str, med_name, quantity, total_price):
    try:
        lines = []
        found = False
        last_date = None

        # Read the existing sales file line by line
        with open("sales.txt", "r") as f:
            for line in f:
                line_date = None
                if line.startswith("====="):
                    # This is a date header line like "===== Sales for 2025-05-26 ====="
                    parts = line.strip().split()
                    if len(parts) >= 4:
                        line_date = parts[3]
                        last_date = line_date  # Keep track of the last date header seen
                    lines.append(line)
                    continue
                else:
                    # This is a sales data line starting with a date
                    parts = line.strip().split()
                    if parts:
                        line_date = parts[0]

                # If the line matches the date and medicine name (case-insensitive), update its quantity and total
                if line_date == date_str and med_name.lower() in line.lower():
                    old_qty = int(parts[3])
                    old_total = int(parts[5])
                    new_qty = old_qty + quantity
                    new_total = old_total + total_price
                    line = f"{date_str} {med_name.capitalize()} Quantity: {new_qty} Total: {new_total}\n"
                    found = True

                lines.append(line)

        # If the sale record was not found, add it
        if not found:
            # If the date is new (different from last date header), add the header first
            if last_date != date_str:
                lines.append(f"===== Sales for {date_str} =====\n")
            lines.append(f"{date_str} {med_name.capitalize()} Quantity: {quantity} Total: {total_price}\n")

        # Write the updated lines back to the file
        with open("sales.txt", "w") as f:
            f.writelines(lines)

    except Exception as e:
        # If an error occurs, log the error and show a message to the user
        log_error(f"Error updating sales file: {e}")
        messagebox.showerror("Error", "Failed to update sales file.")

def update_customer_history(customer_name, purchased_medicines, date_str):
    """Update purchase history for a customer (append to same line if customer exists)."""
    try:
        new_entry = f"{date_str}"
        for med, qty in purchased_medicines.items():
            new_entry += f",{med}:{qty}"

        lines = []
        found = False

        with open("customers.txt", "r") as f:
            for line in f:
                if line.lower().startswith(customer_name.lower() + "|"):
                    # Append new entry to existing customer line
                    line = line.strip() + "|" + new_entry + "\n"
                    found = True
                lines.append(line)

        if not found:
            lines.append(f"{customer_name}|{new_entry}\n")

        with open("customers.txt", "w") as f:
            f.writelines(lines)

    except Exception as e:
        log_error(f"Error updating customer history: {e}")
        messagebox.showerror("Error", "Failed to update customer history.")

# ------------------ Main ------------------

if __name__ == "__main__":
    check_files()
    root = tk.Tk()
    root.title("Pharmacy Management System")
    login_gui(root)
    root.mainloop()
